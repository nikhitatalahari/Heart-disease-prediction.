import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report
import tkinter as tk
from tkinter import filedialog, messagebox


class HeartDiseaseClassifierApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Heart Disease Classifier")

        # Create widgets
        self.load_data_button = tk.Button(master, text="Load Data", command=self.load_data)
        self.load_data_button.pack(pady=10)

        self.train_button = tk.Button(master, text="Train and Evaluate", command=self.train_and_evaluate,
                                      state=tk.DISABLED)
        self.train_button.pack(pady=5)

        self.results_text = tk.Text(master, height=20, width=60)
        self.results_text.pack(pady=10)

        self.quit_button = tk.Button(master, text="Quit", command=self.master.quit)
        self.quit_button.pack(pady=5)

        self.data = None

    def load_data(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "heart.csv")])
        if file_path:
            self.data = pd.read_csv(file_path)
            self.train_button.config(state=tk.NORMAL)
            messagebox.showinfo("Success", "Data loaded successfully!")
        else:
            messagebox.showerror("Error", "No file selected!")

    def train_and_evaluate(self):
        if self.data is not None:
            # Split data
            x_train, x_test, y_train, y_test = train_test_split(self.data.drop(columns=["target"]), self.data["target"])
            # Loading the algorithms
            clf = [DecisionTreeClassifier(), RandomForestClassifier(n_estimators=10), SVC(gamma="scale"),
                   KNeighborsClassifier(), MultinomialNB()]
            algo = ["Decision Tree", "Random Forest", "Support Vector", "K Nearest Neighbors", "Naive Bayes"]
            results = ""
            for i, model in enumerate(clf):
                model.fit(x_train, y_train)
                predict = model.predict(x_test)
                accuracy = accuracy_score(y_test, predict) * 100
                report = classification_report(y_test, predict)
                results += f"{algo[i]}\nAccuracy: {accuracy:.2f}%\nClassification Report:\n{report}\n{'-' * 50}\n"
            self.results_text.insert(tk.END, results)
        else:
            messagebox.showerror("Error", "Please load data first!")


def main():
    root = tk.Tk()
    app = HeartDiseaseClassifierApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
